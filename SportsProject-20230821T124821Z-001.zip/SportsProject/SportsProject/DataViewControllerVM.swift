//
//  DataViewControllerVM.swift
//  SurveyForm
//
//  Created by User on 17/08/23.
//

import Foundation
//
//  DetailsViewControllerVM.swift
//  PropertyListDemo
//
//  Created by Instructor on 17/08/23.
//

import Foundation

class DetailsViewControllerVM {
    var name : String = ""
    var email : String = ""
    var phone : String = ""
    var event : Date = Date.now
    var comfort : Int?
    var safety : Int?
    var security : Int?
}

