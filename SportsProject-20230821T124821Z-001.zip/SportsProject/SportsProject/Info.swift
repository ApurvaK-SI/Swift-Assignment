//
//  Info.swift
//  SurveyForm
//
//  Created by User on 17/08/23.
//

import Foundation

struct Info {
    var name : String = ""
    var email : String = ""
    var phone : String = ""
    var event : Date = Date.now
    var comfort : Int = 0
    var safety : Int = 0
    var security : Int = 0
}

extension Info : Codable {
    
}

extension Info : CustomStringConvertible {
    var description: String {
        """
        Info
        -----
        NAME       \(self.name)
        EMAIL:    \(self.email)
        PHONE:       \(self.phone)
        EVENT:      \(self.event.description)
        COMFORT:    \(self.comfort)
        SAFETY:     \(self.safety)
        SECURITY:   \(self.security)
        """
    }
}
