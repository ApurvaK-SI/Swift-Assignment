//
//  DetailsViewController.swift
//  PropertyListDemo
//
//  Created by Instructor on 17/08/23.
//

import UIKit

class DetailsViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
            self.nameInfo.text  = self.viewModel.name
            self.mailInfo.text = self.viewModel.email
            self.phoneNumber.text = self.viewModel.phone
            self.comfortInfo.text = "\(self.viewModel.comfort ?? 0)"
            self.safetyInfo.text = "\(self.viewModel.safety ?? 0)"
            self.securityInfo.text = "\(self.viewModel.security ?? 0)"
        self.dateInfo.text    = self.viewModel.event.description
        }
        
        //MARK: - Variables
        var viewModel : DetailsViewControllerVM = DetailsViewControllerVM()
        
        //MARK: - IBOutlets
    
    
    @IBOutlet weak var phoneNumber: UILabel!
    @IBOutlet weak var securityInfo: UILabel!
    @IBOutlet weak var safetyInfo: UILabel!
   
    @IBOutlet weak var comfortInfo: UILabel!
    
    @IBOutlet weak var dateInfo: UILabel!
    @IBOutlet weak var mailInfo: UILabel!
    @IBOutlet weak var nameInfo: UILabel!
    /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }

