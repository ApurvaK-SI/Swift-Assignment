//
//  ViewController.swift
//  SurveyForm
//
//  Created by User on 16/08/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var surveyName: UITextField!
    
    @IBOutlet weak var surveyEmail: UITextField!
    @IBOutlet weak var surveyPhoneNo: UITextField!
    
    
    @IBOutlet weak var eventDate: UIDatePicker!
    @IBOutlet weak var comfortRate: UISegmentedControl!
    @IBOutlet weak var safetyRate: UISegmentedControl!
    @IBOutlet weak var securityRate: UISegmentedControl!
    
    var viewModel : ViewControllerVM  = ViewControllerVM()
    
    
    @IBAction func surveyPageUI(_ sender: UIButton) {
    }
    @IBAction func newsurveyTapped(_ sender: UIButton) {
    }
    @IBAction func saveTapped(_ sender: UIButton) {
        self.viewModel.name  = self.surveyName.text!
        self.viewModel.email = self.surveyEmail.text!
        self.viewModel.phone = self.surveyPhoneNo.text!
        self.viewModel.comfort = self.comfortRate.selectedSegmentIndex
        self.viewModel.safety = self.safetyRate.selectedSegmentIndex
        self.viewModel.security = self.securityRate.selectedSegmentIndex
        self.viewModel.event    = self.eventDate.date
        self.viewModel.save()
    }
    @IBAction func cancelSurvey(_ sender: UIButton) {
    }
}

